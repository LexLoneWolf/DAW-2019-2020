<?php 
    $edad = $_GET["edad"];
    $anyoActual = date("Y");
    $jubilacion = 65-$edad;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>206anyos</title>
</head>
<body>

    <p><?php echo "Edad actual $edad"; ?></p>

    <p>
        <?php echo "Dentro de 10 años tendrá " . ($edad+10) . 
        " (" . ($anyoActual+10) . ")";
        ?>
    </p>
    
    <p>
        <?php echo "Hace 10 años tenía " . ($edad-10) . 
        " (" . ($anyoActual-10) . ")"; 
        ?>
    </p>
    
    <p>
        <?php 
            echo "Año de jubilación (" . ($anyoActual+$jubilacion) . ")";
        ?>
    </p>
    
</body>
</html>