<?php 

    $filas = $_GET["filas"];
    $columnas = $_GET["columnas"];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css">
    <title>226tabla</title>
</head>
<body>
    <table>
    
        <?php 
        for ($i=1; $i <= $filas; $i++) { 
        ?>
            <tr>
                <?php
                for ($j=1; $j <= $columnas; $j++) { 
                ?>
                    <td><?= "$i:$j" ?></td>
                <?php } ?>
            </tr>
        <?php } ?>
    
    </table>
</body>
</html>