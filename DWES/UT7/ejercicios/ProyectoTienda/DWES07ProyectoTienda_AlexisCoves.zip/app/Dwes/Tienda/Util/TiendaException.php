<?php 

namespace Dwes\Tienda\Util;

use Exception;

class TiendaException extends Exception {

}
