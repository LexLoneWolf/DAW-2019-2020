 <?php

const DSN = "mysql:host=localhost;dbname=dwes";
const USUARIO = "dwes";
const PASSWORD = "abc123.";
const CANAL = "Tienda";
const RUTALOGS = "config/logs/tienda.log";
