<?php 

namespace Dwes\Tienda;

use Exception;

class TiendaException extends Exception {

}
