<?php 

include "vendor/autoload.php";

use Dwes\Tienda\Tienda;

if (!isset($_GET['id'])) {
    echo "Seleccione una tienda";
} else {
    $tienda = new Tienda(1, "Tienda", "691317652");
    include "formEditarTienda.php";
}

