<?php 

include "config/configuracion.php";
include "vendor/autoload.php";

use Dwes\Tienda\LogFactory;
use Dwes\Tienda\TiendaException;

$nombre = $_POST["nombre"] ?? "";
$tlf = $_POST["tlf"] ?? "";
$nombreErr = $tlfErr = "";
$log = Logfactory::getLogger(CANAL);

$obligatorio = "Campo obligatorio";
$ok = false;

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $ok = true;
    if (empty($_POST["nombre"])) {
        $nombreErr = $obligatorio;
        $ok = false;
    } else {
        $opciones = array("options" => array("regexp" => "/^[a-zA-Záéíóú\s]*$/"));
        if (!filter_var($nombre, FILTER_VALIDATE_REGEXP, $opciones)) {
            $nombreErr = "Sólo se permiten letras y espacios en blanco";
            $ok = false;
        }
    }

    if (isset($_POST["tlf"])) {
        $opciones = array("options" => array("regexp" => "/^(6|7|9)[0-9]{8}$/"));
        if (!filter_var($tlf, FILTER_VALIDATE_REGEXP, $opciones)) {
            $tlfErr = "Teléfono no válido";
            $ok = false;
        }
    }
}

if ($ok) {
    $conexion = null;

    try {
        $conexion = new PDO(DSN, USUARIO, PASSWORD);
        $conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $sql = "INSERT INTO tienda(nombre,tlf) VALUES (:nombre, :tlf);";

        $sentencia = $conexion->prepare($sql);
        $sentencia->bindParam(":nombre", $nombre);
        $sentencia->bindParam(":tlf", $tlf);

        $isOk = $sentencia->execute();
        $cod = $conexion->lastInsertId();
    } catch (PDOException $e) {
        $log->error($e->getMessage());
        throw new TiendaException($e->getMessage());        
    }

    $conexion = null;

    $datos = ['cod' => $cod, 'nombre' => $nombre, 'tlf' => $tlf];
    $log->info("Insertada tienda:", $datos);
} else {
    include "formAltaTienda.php";
}
