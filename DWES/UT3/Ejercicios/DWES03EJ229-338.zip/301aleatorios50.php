<?php 

    $numeros = [];

    for ($i=0; $i < 50; $i++) { 
       $n = rand(1,1000);
       $numeros[$i] = $n;     
    }
   
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>301aleatorios50</title>
</head>
<body>

    <ul>
        <?php
        foreach ($numeros as $numero) {  
        ?>
            <li><?= $numero ?></li>
        <?php } ?>
    </ul>
    
</body>
</html>

