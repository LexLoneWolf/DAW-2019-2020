<?php 

    $cantidad = $_GET["cantidad"];
    $personas = [];
    $alturaMax = 0;
    $alturaMin = 0;
    $alto = [];
    $bajo = [];

    for ($i=0; $i < $cantidad; $i++) { 
        $personas[$i] = array(
            $_GET["nombre$i"],
            $_GET["altura$i"],
            $_GET["email$i"]
        );

        if ($alturaMax < $personas[$i][1]) {
            $alturaMax = $personas[$i][1];
            $alto = $personas[$i];
        }  
    }

    $alturaMin = $alturaMax;

    for ($i=0; $i < count($personas); $i++) { 
        if ($alturaMin > $personas[$i][1]) {
            $alturaMin = $personas[$i][1];
            $bajo = $personas[$i];
        }
    }

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>309gestionarPersonas</title>
</head>
<body>
    <table border="1%" width="15%">
        <tr>
            <th>Nombre</th>
            <th>Altura</th>
            <th>Email</th>
        </tr>
        <?php
        foreach ($personas as $persona) { ?>
            <tr>
                <td><?= $persona[0] ?></td>
                <td><?= $persona[1] ?></td>
                <td><?= $persona[2] ?></td>
            </tr>
        <?php } ?>
        <tr><th colspan="3">Más alto</th></tr>
        <tr>
            
            <td><?= $alto[0] ?></td>
            <td><?= $alto[1] ?></td>
            <td><?= $alto[2] ?></td>
        </tr>

        <tr><th colspan="3">Más bajo</th></tr>
        <tr>
            
            <td><?= $bajo[0] ?></td>
            <td><?= $bajo[1] ?></td>
            <td><?= $bajo[2] ?></td>
        </tr>
    </table>

</body>
</html>