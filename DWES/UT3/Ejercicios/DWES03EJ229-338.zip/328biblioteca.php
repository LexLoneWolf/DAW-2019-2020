<?php 

    //Función que suma 2 números
    function sumar(int $n1, int $n2): int {
        return $n1 + $n2;
    }

    function restar(int $n1, int $n2): int {
        return $n1 - $n2;
    }

    function multiplicar(int $n1, int $n2): int {
        return $n1 * $n2;
    }

    function dividir(int $n1, int $n2): float {
        return $n1 / $n2;
    }

?>