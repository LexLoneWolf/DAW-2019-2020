<?php 

    $menu = array("Primer plato" => "Fajitas", "Segundo Plato" => "Crema de verdudas", 
    "Bebida" => "Agua/Resfresco", "Postre" => "Helado");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>306menu</title>
</head>
<body>
    <table border="1%" width="20%">
        <?php foreach ($menu as $key => $value) { ?>
            <tr>
                <th><?= $key ?></th>
                <td><?= $value ?></td>
            </tr>
        <?php } ?>

    </table>
</body>
</html>