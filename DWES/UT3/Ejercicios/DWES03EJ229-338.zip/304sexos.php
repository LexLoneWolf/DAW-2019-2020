<?php 

    $sexos = [];
    $hombres = 0;
    $mujeres = 0;

    for ($i=0; $i < 100; $i++) { 
        $n = rand(0,1);
        if ($n == 0) {
            $sexos[$i] = "M";
        } else {
            $sexos[$i] = "F";
        }
        
    }

    foreach ($sexos as $sexo) {
        if ($sexo == "M") {
            $hombres++;
        } else {
            $mujeres++;
        }

    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>304sexos</title>
</head>
<body>

    <p>Hombres: <?= $hombres ?> Mujeres: <?= $mujeres ?></p>
    
</body>
</html>