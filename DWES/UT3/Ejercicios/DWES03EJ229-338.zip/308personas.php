<?php 

    $personas = array(
        array("Alexis", 1.85, "lareone91@gmail.com"),
        array("Laura", 1.58, "laura.rgar@gmail.com"),
        array("Ainhoa", 1.61, "correoainhoa@gmail.com"),
        array("Moises", 1.89, "correomoises@gmail.com"),
        array("Daniel", 1.72, "correodaniel@gmail.com")
    );

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>308personas</title>
</head>
<body>
    <table border="1%" width="15%">
        <tr>
            <th>Nombre</th>
            <th>Altura</th>
            <th>Email</th>
        </tr>
        <?php
        foreach ($personas as $persona) { ?>
            <tr>
                <td><?= $persona[0] ?></td>
                <td><?= $persona[1] ?></td>
                <td><?= $persona[2] ?></td>
            </tr>
        <?php } ?>
    </table>
</body>
</html>