<?php 

    $numeros = [];
    for ($i=0; $i < 33; $i++) { 
       $n = rand(1,100);
       $numeros[$i] = $n;     
    }

    sort($numeros);
    $mayor = $numeros[count($numeros)-1];
    $menor = $numeros[0];
    $media = array_sum($numeros)/count($numeros);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>303mates</title>
</head>
<body>

    <p>El número mayor es: <?= $mayor ?></p>
    <p>El número menor es: <?= $menor ?></p>
    <p>La media es: <?= $media ?></p>

</body>
</html>