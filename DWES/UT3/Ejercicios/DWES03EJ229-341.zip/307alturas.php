<?php 

    $alturas = array(
        "Alexis" => 1.85, 
        "Laura" => 1.58,
        "Ainhoa" => 1.61, 
        "Moises" => 1.89, 
        "Daniel" => 1.72
    );

    $media = array_sum($alturas)/count($alturas);
    
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>307alturas</title>
</head>
<body>
    <table border="1%" width="15%">
        <tr>
            <th>Nombre</th>
            <th>Altura</th>
        </tr>
        <?php
        foreach ($alturas as $nombre => $altura) { ?>
            <tr>
                <td><?= $nombre ?></td>
                <td><?= $altura ?></td>
            </tr>
        <?php } ?>
        <tr>
            <td>Altura media</td>
            <td><?= $media ?></td>
        </tr>
    </table>
</body>
</html>