<?php 

    $pregunta = $_GET["pregunta"];
    $respuestas = [
    "Sí",
    "No",
    "Seguro",
    "Claro que sí",
    "No lo creo", 
    "Quizá", 
    "Soñar es gratis"
    ];

    $n = rand(0,count($respuestas)-1);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>302bola8</title>
</head>
<body>
    <p><?= $pregunta ?></p>
    <p><?= $respuestas[$n] ?></p>
</body>
</html>