<?php 
    define("N", 10);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>229cuadradoMultiplicar</title>
</head>
<body>
    <table width="25%" border="1%">
        <th style="background-color:blue; color:white;">X</th>
        <?php
        for ($i=0; $i <= N; $i++) { 
        ?>
            <th style="background-color:blue; color:white;"><?= $i ?></th>
        <?php }
        for ($i=0; $i <= N; $i++) { 
        ?>
            <tr>
                <th style="background-color:orange; color:white;"><?= $i ?></th>
                <?php
                for ($j=0; $j <= N; $j++) {   
                ?> 
                    <td><?= $i*$j ?></td>    
                <?php } ?>
            </tr>
        <?php } ?>
    </table>
</body>
</html>