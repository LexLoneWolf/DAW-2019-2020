<?php 

    $cantidad = $_GET["cantidad"];
    $cantBill = array(500 => 0,200 => 0,100 => 0,50 => 0,20 => 0,10 =>0, 5 => 0,2 => 0,1 => 0);

    foreach ($cantBill as $billete => $value) {
        $cantBill[$billete] = intval($cantidad/$billete);
        $cantidad %= $billete;
    }
    
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>305monedas</title>
</head>
<body>

    <ul>
        <?php 
        foreach ($cantBill as $billete => $value) {
            if ($value > 0) {
                if ($billete > 4) { ?>  
                    <li><?= $value ?> Billete/s de <?= $billete ?></li>
        <?php   } else { ?>
                <li><?= $value ?> Moneda/s de <?= $billete ?></li>
        <?php   }
            }
        } ?>
    </ul>

</body>
</html>