<?php 

    function esPar($num): bool {

        $par = false;

        if ($num % 2 == 0) {
            $par = true;
        } else {
            $par = false;
        }

        return $par;

    }

    function aleatorio($min,$max,$tam): array {
        $numeros = [];
        $n = 0;

        for ($i=0; $i < $tam; $i++) { 
            $n = rand($min,$max);
            $numeros[] = $n;   
        }

        return $numeros;
    }

    function cantidadPares(&$array): int {
        $pares = 0;

        for ($i=0; $i < count($array); $i++) { 
            if (esPar($array[$i])) {
                $pares++;
            }
        }
        return $pares;
    }

    ///Comprobación de función esPar

    /*$num = $_GET["num"];

    if (esPar($num)) {
        echo "El número $num es par";
    } else {
        echo "El número $num es impar";
    }*/


    //Comprobación de función aleatorios

    /*$min = $_GET["min"];
    $max = $_GET["max"];
    $tam = $_GET["tam"];
    $n = 0;
    $numeros = aleatorio($min,$max,$tam);
    print_r($numeros);

    /// Comprobación de función cantidadPares

    $n = cantidadPares($numeros);
    echo $n;*/
    
?>