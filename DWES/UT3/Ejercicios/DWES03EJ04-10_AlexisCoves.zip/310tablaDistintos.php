<?php 

    define("FIL",6);
    define("COL",9);
    $numeros = [];
    $numIntroducidos = [];
    $n = rand(100,999);
    $columna = 0;
    $color = "";

    for ($i=0; $i < FIL; $i++) { 
        for ($j=0; $j < COL; $j++) {
            $numeros[$i][$j] = 0;
        }
    }

    for ($i=0; $i < FIL; $i++) { 

        for ($j=0; $j < COL; $j++) {
            while(in_array($n, $numIntroducidos)) {
                $n = rand(100,999);
            }

            $numeros[$i][$j] = $n;
            $numIntroducidos[] = $n;
            $n = rand(100,999);   
        }     
    }

    $max = max($numIntroducidos);
    $min = min($numIntroducidos);

    for ($i=0; $i < FIL; $i++) { 
        for ($j=0; $j < COL; $j++) {
            if ($max == $numeros[$i][$j]) {
                $columna = $j;
            }
        }
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>310tabladistintos</title>
</head>
<body>
    <table border="1%">
        <?php
        for ($i=0; $i < FIL; $i++) { ?>
            <tr>
                <?php 
                for ($j=0; $j < COL; $j++) { 
                    if (in_array($min, $numeros[$i])) {
                        $color = "color:green;";
                    } else if ($j == $columna) {
                        $color = "color:blue;";
                    } else {
                        $color = "color:black;";
                    } ?>
                    <td style ="<?= $color ?>"><?= $numeros[$i][$j] ?></td>
                <?php 
                } ?>
            </tr>
        <?php } ?>
    </table>
</body>
</html>