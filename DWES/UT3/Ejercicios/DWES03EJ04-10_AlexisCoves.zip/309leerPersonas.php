<?php 

    $cantidad = $_GET["cantidad"];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>209leerPersonas</title>
</head>
<body>
    <form action="309gestionarPersonas.php" method="get">

        <?php
        for ($i=0; $i < $cantidad; $i++) { ?>
            <fieldset>
                <legend>Persona <?= $i ?></legend>
                <label for="nombre<?= $i ?>">Nombre: </label>
                <input type="text" name="nombre<?= $i ?>" id="nombre<?= $i ?>" />
                <label for="altura<?= $i ?>">Altura: </label>
                <input type="number" name="altura<?= $i ?>" step=".01" id="altura<?= $i ?>" />
                <label for="email<?= $i ?>">Email: </label>
                <input type="mail" name="email<?= $i ?>" id="email<?= $i ?>" />
            </fieldset>
        <?php } ?>
        <input type="hidden" name="cantidad" value="<?= $cantidad ?>" />
        <input type="submit" id="Enviar" />
    </form>
</body>
</html>