<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>601server</title>
</head>
<body>
    <form action="601server.php" method="POST">
        <label for="nombre">Nombre: </label>
        <input type="text" id="nombre">
    </form>
</body>
</html>
