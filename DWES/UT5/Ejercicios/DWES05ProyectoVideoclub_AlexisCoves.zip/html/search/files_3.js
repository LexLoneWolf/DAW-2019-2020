var searchData=
[
  ['logfactory_2ephp_91',['LogFactory.php',['../_log_factory_8php.html',1,'']]]
];
