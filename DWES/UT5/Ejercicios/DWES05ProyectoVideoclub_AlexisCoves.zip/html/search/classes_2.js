var searchData=
[
  ['juego_74',['Juego',['../class_dwes_1_1_videoclub_1_1_model_1_1_juego.html',1,'Dwes::Videoclub::Model']]]
];
