var searchData=
[
  ['juego_40',['Juego',['../class_dwes_1_1_videoclub_1_1_model_1_1_juego.html',1,'Dwes::Videoclub::Model']]],
  ['juego_2ephp_41',['Juego.php',['../_juego_8php.html',1,'']]]
];
