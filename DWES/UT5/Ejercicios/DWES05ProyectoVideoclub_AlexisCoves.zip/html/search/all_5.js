var searchData=
[
  ['getalquilado_26',['getAlquilado',['../class_dwes_1_1_videoclub_1_1_model_1_1_soporte.html#a6777f9225322f0d8318a85d5eb663d98',1,'Dwes::Videoclub::Model::Soporte']]],
  ['getlogger_27',['getLogger',['../class_dwes_1_1_videoclub_1_1_util_1_1_log_factory.html#a21d3d0df8204f3bb43e5b594e4e95a4f',1,'Dwes::Videoclub::Util::LogFactory']]],
  ['getnumero_28',['getNumero',['../class_dwes_1_1_videoclub_1_1_model_1_1_cliente.html#aac837c7f73ec485f8ddc6118e6f5c15f',1,'Dwes\Videoclub\Model\Cliente\getNumero()'],['../class_dwes_1_1_videoclub_1_1_model_1_1_soporte.html#aac837c7f73ec485f8ddc6118e6f5c15f',1,'Dwes\Videoclub\Model\Soporte\getNumero()']]],
  ['getnumproductosalquilados_29',['getNumProductosAlquilados',['../class_dwes_1_1_videoclub_1_1_model_1_1_video_club.html#a7080e6bd13bed04fca31d06cd0cce2d1',1,'Dwes::Videoclub::Model::VideoClub']]],
  ['getnumtotalalquileres_30',['getNumTotalAlquileres',['../class_dwes_1_1_videoclub_1_1_model_1_1_video_club.html#a8cf105e10aca23b208f503e83959c8ff',1,'Dwes::Videoclub::Model::VideoClub']]],
  ['getprecio_31',['getPrecio',['../class_dwes_1_1_videoclub_1_1_model_1_1_soporte.html#ae1f5d7a6ecf229ebc209b561477ae5ec',1,'Dwes::Videoclub::Model::Soporte']]],
  ['getprecioconiva_32',['getPrecioConIva',['../class_dwes_1_1_videoclub_1_1_model_1_1_soporte.html#aea413508170fdd7e202ccdf191163e23',1,'Dwes::Videoclub::Model::Soporte']]],
  ['getsocio_33',['getSocio',['../class_dwes_1_1_videoclub_1_1_model_1_1_video_club.html#a3b544618198966489c4ee636d967e351',1,'Dwes::Videoclub::Model::VideoClub']]]
];
