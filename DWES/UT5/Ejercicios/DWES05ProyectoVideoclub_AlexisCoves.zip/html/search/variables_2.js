var searchData=
[
  ['singleton_139',['Singleton',['../namespace_dwes_1_1_videoclub_1_1_util.html#a90c7994df18fc2d358849f9a46502bc1',1,'Dwes::Videoclub::Util']]]
];
