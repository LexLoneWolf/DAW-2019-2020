var searchData=
[
  ['logger_150',['Logger',['../namespace_dwes_1_1_videoclub_1_1_util.html#a79f374a17552b31e3b05e126ee50c964',1,'Dwes::Videoclub::Util']]]
];
