var searchData=
[
  ['logger_2ephp_96',['Logger.php',['../_logger_8php.html',1,'']]]
];
