var searchData=
[
  ['juego_80',['Juego',['../class_dwes_1_1_videoclub_1_1_model_1_1_juego.html',1,'Dwes::Videoclub::Model']]]
];
