<?php  

namespace Dwes\Videoclub\Model;

use PHPUnit\Framework\TestCase;

class CintaVideoTest extends TestCase {

    /**
     * @dataProvider cintasProvider
     */
    public function testConstructor($titulo, $id, $precio, $duracion) {
        $cv = new CintaVideo($titulo, $id, $precio, $duracion);
        $this->assertSame($titulo, $cv->titulo);
        $this->assertSame($id, $cv->getNumero());
        $this->assertSame($precio, $cv->getPrecio());
        $this->assertSame($duracion, $cv->getDuracion());
    }

    /**
     * @dataProvider cintasProvider
     */
    public function testMuestraResumenConProvider($titulo, $id, $precio, $duracion, $esperado) {
        $cv = new CintaVideo($titulo, $id, $precio, $duracion);
        $this->assertSame($esperado, $cv->muestraResumen());
    }

    public function cintasProvider() {
        return [
            "Cazafantasmas" => ["Los Cazafantasmas", 1, 3.5, 107, "Pelicula en VHS:<br /> Los Cazafantasmas <br />3.5 (IVA no incluido)Duración: 107 minutos"]
        ];
    }



}