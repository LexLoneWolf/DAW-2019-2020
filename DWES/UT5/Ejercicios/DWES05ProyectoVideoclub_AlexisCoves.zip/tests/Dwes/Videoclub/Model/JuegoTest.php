<?php  

namespace Dwes\Videoclub\Model;

use PHPUnit\Framework\TestCase;

class JuegoTest extends TestCase {

    /**
     * @dataProvider juegoProvider
     */
    public function testConstructor($titulo, $id, $precio, $consola, $minNumJugadores, $maxNumJugadores) {
        $juego = new Juego($titulo, $id, $precio, $consola, $minNumJugadores, $maxNumJugadores);
        $this->assertSame($titulo, $juego->titulo);
        $this->assertSame($id, $juego->getNumero());
        $this->assertSame($precio, $juego->getPrecio());
        $this->assertSame($consola, $juego->getConsola());
        $this->assertSame($minNumJugadores, $juego->getMinNumJugadores());
        $this->assertSame($maxNumJugadores, $juego->getMaxNumJugadores());
    }

    /**
     * @dataProvider juegoProvider
     */
    public function testMuestraJugadoresPosibles($titulo, $id, $precio, $consola, $minNumJugadores, $maxNumJugadores) {
        $juego = new Juego($titulo, $id, $precio, $consola, $minNumJugadores, $maxNumJugadores);
        $this->expectOutputString("<br />Para un jugador");
        $juego->muestraJugadoresPosibles();
    }

    /**
     * @dataProvider juegoProvider
     */
    public function testMuestraResumen($titulo, $id, $precio, $consola, $minNumJugadores, $maxNumJugadores, $esperado) {
        $juego = new Juego($titulo, $id, $precio, $consola, $minNumJugadores, $maxNumJugadores);
        $this->assertSame($esperado, $juego->muestraResumen());
    }

    public function juegoProvider() {
        // "God of War",19.99,"PS4",1,1
        return [
            "Gow" => ["God of War", 1, 19.99, "PS4", 1, 1, "<br />Juego para: PS4<br /> God of War <br />19.99 (IVA no incluido)"] 
        ];
    }
}
