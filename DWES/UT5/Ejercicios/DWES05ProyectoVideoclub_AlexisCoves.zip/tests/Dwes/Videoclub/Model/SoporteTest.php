<?php 

namespace Dwes\Videoclub\Model;

use PHPUnit\Framework\TestCase;

// class SoporteTest extends TestCase {

//     /**
//      * @dataProvider soporteProvider
//      */
//     public function constructorTest() {

//     }

//     public function testprecioConIvaProvider() {

//     }

//     public function soporteProvider() {
//         return [

//         ];
//     }

// }