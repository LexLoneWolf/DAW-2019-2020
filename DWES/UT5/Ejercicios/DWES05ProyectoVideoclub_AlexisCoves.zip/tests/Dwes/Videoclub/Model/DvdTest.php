<?php  

namespace Dwes\Videoclub\Model;

use PHPUnit\Framework\TestCase;

class DvdTest extends TestCase {

    /**
     * @dataProvider dvdProvider
     */
    public function testConstructor($titulo, $id, $precio, $idiomas, $formatoPantalla) {
        $dvd = new Dvd($titulo, $id, $precio, $idiomas, $formatoPantalla);
        $this->assertSame($titulo, $dvd->titulo);
        $this->assertSame($id, $dvd->getNumero());
        $this->assertSame($precio, $dvd->getPrecio());
        $this->assertSame($idiomas, $dvd->getIdiomas());
        $this->assertSame($formatoPantalla, $dvd->getFormatoPantalla());
    }

    /**
     * @dataProvider dvdProvider
     */
    public function testMuestraResumenConProvider($titulo, $id, $precio, $idiomas, $formatoPantalla, $esperado) {
        $dvd = new Dvd($titulo, $id, $precio, $idiomas, $formatoPantalla);
        $this->assertSame($esperado, $dvd->muestraResumen());
    }

    public function dvdProvider() {
        // "El Imperio Contraataca",3,"es,en","16:9"
        return [
            "starWars" => ["El imperio contraataca", 1, 3.0, "es,en", "16:9", "<br />Pelicula en DVD:<br /> El imperio contraataca <br />3 (IVA no incluido)<br />Idiomas: es,en<br />Formato: 16:9"] 
        ];
    }
}
