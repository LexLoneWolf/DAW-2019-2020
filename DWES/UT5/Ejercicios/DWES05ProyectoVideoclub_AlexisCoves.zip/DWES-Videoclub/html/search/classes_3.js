var searchData=
[
  ['logfactory_75',['LogFactory',['../class_dwes_1_1_videoclub_1_1_util_1_1_log_factory.html',1,'Dwes::Videoclub::Util']]]
];
