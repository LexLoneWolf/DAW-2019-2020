<?php 

namespace Dwes\Videoclub\Util;

/**
 * Excepción de cupo superado
 * 
 * se lanza cuando el cliente ha alcanzado su número máximo de alquileres
 * e intenta alquilar de nuevo.
 * 
 * @package Dwes\Videoclub\Util
 * @author LexLoneWolf <lareone91@gmail.com>
 */
class CupoSuperadoException extends VideoclubException {

    /**
     * Lanza un mensaje indicando que el cliente ha alcanzado el límite de alquileres
     * @return void
     */
    public function cupoSuperado(): void {
        echo "Este cliente tiene " . $this->message .
        " elementos alquilados. No puede alquilar más en este videoclub hasta que no devuelva algo<br />";
    }
}
