<?php 

namespace Dwes\Videoclub\Util;

/**
 * Excepción de soporte ya alquilado
 * 
 * Se lanza cuando el cliente intenta alquilar un soporta que ya tiene alquilado
 * 
 * @package Dwes\Videoclub\Util
 * @author LexLoneWolf <lareone91@gmail.com>
 */
class SoporteYaAlquiladoException extends VideoclubException {
    
    /**
     * Lanza un mensaje de advertencia indicando que el cliente ya tiene alquilado el soporte
     * @return void
     */
    public function yaAlquilado() : void {
        echo "El cliente ya tiene alquilado el soporte: <strong>" . $this->message . "</strong>";
    }
}
