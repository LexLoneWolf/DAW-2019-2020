<?php 

namespace Dwes\Videoclub\Model;

use Monolog\Logger;

class Juego extends Soporte implements Resumible {

    //Atributos
    /**
     * Tipo de consola: Xbox, Playstation..
     * @var int
     */
    public $consola;
    /**
     * Número mínimo de jugadores
     * @var int
     */
    private $minNumJugadores;
    /**
     * Número máximo de jugadores
     * @var int
     */
    private $maxNumJugadores;

    //Constructor 
    public function __construct(string $titulo, int $numero, float $precio, string $consola, int $minNumJugadores, int $maxNumJugadores) {
        parent::__construct($titulo, $numero, $precio);
        $this->consola = $consola;
        $this->minNumJugadores = $minNumJugadores;
        $this->maxNumJugadores = $maxNumJugadores;
        $this->log = new Logger("VideoclubLogger");
    }

    //Métodos
    /**
     * Muestra la cantidad de jugadores posibles
     * 
     * En función del número de jugadores muestra si es para 
     * 1 jugador, para x jugadores, o un intervalo.
     * 
     * @return void
     */
    public function muestraJugadoresPosibles(): void {
        if ($this->minNumJugadores == 1 && $this->maxNumJugadores == 1) {
            echo "<br />Para un jugador";
        } else if ($this->minNumJugadores == $this->maxNumJugadores) {
            echo "<br />Para " . $this->minNumJugadores . " jugadores";
        } else {
            echo "<br />De " . $this->minNumJugadores . " a " . $this->maxNumJugadores;
        }
    }

    /**
     * Muestra un resumen con las propiedades del juego
     * @return void
     */
    public function muestraResumen(): void {
        echo ("<br />Juego para: " . $this->consola .
        parent::muestraResumen() .
        $this->muestraJugadoresPosibles());
    }
}
