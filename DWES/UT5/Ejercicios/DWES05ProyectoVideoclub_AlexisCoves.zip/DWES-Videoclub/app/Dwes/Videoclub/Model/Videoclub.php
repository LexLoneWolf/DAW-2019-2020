<?php 

namespace Dwes\Videoclub\Model;

use \Dwes\Videoclub\Util\SoporteYaAlquiladoException;
use \Dwes\Videoclub\Util\CupoSuperadoException;
use \Dwes\Videoclub\Util\SoporteNoEncontradoException;
use \Dwes\Videoclub\Util\VideoclubException;
use \Dwes\Videoclub\Util\LogFactory;

/**
 * Clase Videoclub
 * 
 * Permite añadir productos y clientes, alquilar y devolver soportes de un cliente
 * listar clientes y productos
 * 
 * @package Dwes\Videoclub\Model
 * @author LexLoneWolf <lareone91@gmail.com>
 */
class VideoClub implements Resumible {

    use \Dwes\Videoclub\Util\Singleton;
    
    //Atributos
    /**
     * Nombre del videoclub
     * @var string
     */
    private string $nombre;
    /**
     * Colección de productos del videoclub
     * @var array <Soporte>
     */
    private array $productos;
    /**
     * Número de productos 
     * @var int
     */
    private int $numProductos;
    /**
     * Colección de socios del videoclub
     * @var array <Cliente>
     */
    private array $socios;
    /**
     * Número de socios
     * @var int
     */
    private int $numSocios;
    /**
     * Número de prodctos alquilados actuales
     * @var int
     */
    private int $numProductosAlquilados;
    /**
     * Número de alquilares totales
     * @var int
     */
    private int $numTotalAlquileres;

    //Constructor
    public function init(string $nombre): Videoclub {
        $this->nombre = $nombre;
        $this->productos = [];
        $this->numProductos = 0;
        $this->socios = [];
        $this->numSocios = 0;
        $this->numProductosAlquilados = 0;
        $this->numTotalAlquileres = 0;
        return $this;
    }

    //Getters 
    public function getNumProductosAlquilados() : int {
        return $this->numProductosAlquilados;
    }

    public function getNumTotalAlquileres() : int {
        return $this->numTotalAlquileres;
    }

    //obtiene un socio del array para probar funciones en inicio.php
    public function getSocio(int $numSocio) : Cliente {
        return $this->socios[$numSocio];
    }

    //Métodos
    /**
     * Añade un producto al array de productos
     * @param Soporte $s Soporte a incluir
     */
    private function incluirProducto(Soporte $s) {
        $datos = [
            "Videoclub" => $this->nombre,
            "Soporte" => $s->getNumero()
        ];
        $this->productos[] = $s;
        $this->numProductos++;
        LogFactory::getlogger()->info("Incluido soporte", $datos);
    }

    /**
     * Añade un soporte CintaVideo llamando al método incluirProducto()
     * @param string $titulo Título de la cinta
     * @param float $precio Precio de la cinta
     * @param int $duracion Duración de la cinta
     */
    public function incluirCintaVideo(string $titulo, float $precio, int $duracion) {
        $cinta = new CintaVideo($titulo, $this->numProductos, $precio, $duracion);
        $this->incluirProducto($cinta);
    }

    /**
     * Añade un soporte Dvd llamando al método incluirProducto()
     * @param string $titulo Título del Dvd
     * @param float $precio Precio del Dvd
     * @param string $idiomas Idiomas del Dvd
     * @param string $formatoPantalla Formato de pantalla del Dvd
     */
    public function incluirDvd(string $titulo, float $precio, string $idiomas, string $formatoPantalla) {
        $dvd = new Dvd($titulo, $this->numProductos, $precio, $idiomas, $formatoPantalla);
        $this->incluirProducto($dvd);
    }

    /**
     * Añade un soporte Juego llamando al método incluirProducto()
     * @param string $titulo Título del juego
     * @param float $precio Precio del juego
     * @param string $consola plataforma del juego
     * @param int $minJ Número mínimo de jugadores del juego
     * @param int $maxJ Número máximo de jugadores del juego
     */
    public function incluirJuego(string $titulo, float $precio, string $consola, int $minJ, int $maxJ) {
        $juego = new Juego($titulo, $this->numProductos, $precio, $consola, $minJ, $maxJ); 
        $this->incluirProducto($juego);
    }

    /**
     * Añade un cliente al array de socios
     * @param string $nombre Nombre del socio
     * @param int $maxAlquileresConcurrentes Número máximo de productos que puede tener alquilado, por defecto es 3
     */
    public function incluirSocio(string $nombre, int $maxAlquileresConcurrentes = 3) {
        $socio = new Cliente($nombre, $this->numSocios, $maxAlquileresConcurrentes);
        $this->numSocios++;
        $this->socios[] = $socio;
        $datos = ["Cliente" => $this->numSocios];
        LogFactory::getlogger()->info("Incluido socio", $datos);
    }

    /**
     * Lista todos los productos incluidos en el videoclub
     * @return void
     */
    public function listarProductos(): void {
        $numProductos = $this->numProductos;
        echo("<br />Listado de los " . $numProductos . " productos disponibles");
        foreach ($this->productos as $producto) {
            echo "<br />" . ($producto->getNumero()+1) . ".-<br />";
            $producto->muestraResumen();
        }
    }

    /**
     * Lista todos los clientes del videoclub
     * @return void
     */
    public function listarSocios(): void {
        $numSocios = $this->numSocios;
        echo "<br />Listado de " . $numSocios . " socios del videoclub:";
        foreach ($this->socios as $socio) {
            echo "<br />" . ($socio->getNumero()+1) . "-<br />" .
            "<br /><strong>Cliente " . $socio->getNumero() . ":</strong> ";
            $socio->muestraResumen();
        }
    }

    /**
     * Alquila un producto a un socio
     * @param int $numSocio Identificador del cliente
     * @param int $numProducto Identificador del producto
     * @throws VideoClubException Lanza una excepción si no encuentra el socio o el producto
     * @throws SoporteYaAlquiladoException Lanza una excepción si el soporta ya está alquilado
     * @throws CupoSuperadoException Lanza una excepción si el cliente ya tiene el máximo de alquileres posibles
     * @return Videoclub
     */
    public function alquilarSocioProducto(int $numSocio, int $numProducto): Videoclub {
        try {
            if (key_exists($numSocio, $this->socios)) {
                if (key_exists($numProducto, $this->productos)) {
                    $this->socios[$numSocio]->alquilar($this->productos[$numProducto]);
                    $this->numProductosAlquilados++;
                    $this->numTotalAlquileres++;
                } else {
                    $datos = [
                    "Cliente" => $numSocio,
                    "Soporte" => $numProducto
                    ];
                    LogFactory::getlogger()->warning("No se pudo alquilar el producto", $datos);
                    throw new VideoclubException("El producto " . $numProducto . " no existe");
                }
            } else {
                $datos = ["Cliente" => $numSocio];
                LogFactory::getlogger()->warning("El Cliente no existe", $datos);
                throw new VideoclubException("El Cliente " . $numSocio . " no existe");
            }
        } catch (SoporteYaAlquiladoException $e) {
            $e->YaAlquilado();
        } catch (CupoSuperadoException $e) {
            $e->cupoSuperado();
        } catch (VideoclubException $e) {
            echo $e->getMessage();
        }
        return $this;
    }

    /**
     * Alquila varios productos a un socio
     * @param int $numSocio Identificador del cliente
     * @param array $numerosProducto Array con los números de los productos a alquilar
     * @throws VideoClubException Lanza una excepción si el soporte no existe
     * @throws SoporteYaAlquiladoException Lanza una excepción si el soporte ya está alquilado
     * @throws CupoSuperadoException Lanza una excepción si el cliente ya ha superado el máximo de alquileres posibles
     * @return Videoclub
     */
    public function alquilarSocioProductos(int $numSocio, array $numerosProducto) : Videoclub {
        try { 
            $alquila = true;
            foreach ($numerosProducto as $producto) {
                if (key_exists($producto, $this->productos)) {
                    if ($this->productos[$producto]->getAlquilado()) {
                        $alquila = false;
                        $datos = [
                        "Cliente" => $numSocio,
                        "Soportes" => $numerosProducto
                        ];
                        LogFactory::getlogger()->warning("No se pudo alquilar el soporte", $datos);
                        throw new VideoclubException("No se pudo alquilar porque el soporte $producto porque ya está alquilado");
                    }
                } else {
                    $alquila = false;
                    $datos = [
                    "Cliente" => $numSocio,
                    "Soportes" => $producto
                    ];
                    LogFactory::getlogger()->warning("No se pudo alquilar el soporte", $datos);
                    throw new VideoclubException("No se pudo alquilar porque el producto $producto no existe");
                }
            }
            if ($alquila) {
                foreach ($numerosProducto as $producto) { 
                    $this->alquilarSocioProducto($numSocio, $producto);
                }        
            }  
        } catch (SoporteYaAlquiladoException $e) {
            $e->YaAlquilado();
        } catch (CupoSuperadoException $e) {
            $e->cupoSuperado();
        } catch (VideoclubException $e) {
            echo ($e->getMessage());
        }
        return $this;
    }

    /**
     * Elimina del array de productos alquilados del cliente el producto indicado
     * @param int $numSocio Identificador del cliente
     * @param int $numProducto Identificador del producto
     * @throws VideoclubException Lanza una excepción si no hay ningún producto alquilado
     * @throws SoporteNoEncontradoException Lanza una excepción si no se ha encontrado el producto
     * @return Videoclub
     */
    public function devolverSocioProducto(int $numSocio, int $numProducto) : Videoclub {
        try {
            $datos = [
            "Cliente" => $numSocio,
            "Soporte" => $numProducto
            ];
            if(key_exists($numSocio, $this->socios)) {
                if (key_exists($numProducto, $this->productos)) {
                    if ($this->numProductosAlquilados > 0) {
                        $this->socios[$numSocio]->devolver($numProducto);
                        $this->numProductosAlquilados--;
                        $this->productos[$numProducto]->setAlquilado(false);
                    } else {
                        LogFactory::getlogger()->warning("No se pudo devolver el soporte", $datos);
                        throw new VideoclubException("No hay ningún producto alquilado");
                    }
                } else {
                    LogFactory::getlogger()->warning("No se pudo devolver el soporte", $datos);
                    throw new VideoclubException("El producto " . $numProducto . " no existe");
                }
            } else {
                LogFactory::getlogger()->warning("No se pudo devolver el soporte", $datos);
                throw new VideoclubException("El cliente " . $numSocio . " no existe");
            }
        } catch (SoporteNoEncontradoException $e) {
            $e->noEncontrado();
        } catch (VideoclubException $e) {
            echo $e->getMessage();
        }
        return $this;
    }

    /**
     * Elimina del array de productos alquilados del cliente los productos indicados
     * @param int $numSocio Identificador del cliente
     * @param array $numerosProducto Array con los números de los productos a dolver
     * @throws VideoclubException Lanza una excepción si no puede devolver el producto porque no está alquilado
     * @throws SoporteNoEncontradoException Lanza una excepción si no encuentra el soporte
     * @return Videoclub
     */
    public function devolverSocioProductos (int $numSocio, array $numerosProducto) : Videoclub {
        try {
            $devuelve = true;
            
            foreach ($numerosProducto as $producto) { 
                if (key_exists($producto, $this->productos)) {
                    if (!$this->productos[$producto]->getAlquilado()) {
                        $devuelve = false;
                        $datos = [
                        "Cliente" => $numSocio,    
                        "Soporte" => $producto
                        ];
                        LogFactory::getlogger()->warning("No se pudo devolver el producto", $datos);
                        throw new VideoclubException("No se pudo devolver el producto $producto porque no está alquilado");
                    }
                } else {
                    $datos = [
                        "Cliente" => $numSocio,    
                        "Soporte" => $producto
                        ];
                        LogFactory::getlogger()->warning("No se pudo devolver el producto", $datos);
                    throw new VideoclubException("No se pudo devolver el $producto porque no existe");
                    $devuelve = false;
                }
            }
            if ($devuelve) {
                foreach ($numerosProducto as $producto) {
                    $this->devolverSocioProducto($numSocio, $producto);
                }    
            }
        } catch (SoporteNoEncontrado $e) {
            $e->noEncontrado();
        } catch (VideoclubException $e) {
            echo $e->getMessage();
        }
        return $this;
    }

    /**
     * Muestra un resumen del videoclub
     * @return void
     */
    public function muestraResumen(): void {
        echo "<br />Videoclub: " . $this->nombre . "<br />" .
        "Productos: " . $this->numProductos . "<br />" .
        "Socios: " . $this->numSocios . "<br />" . 
        "Productos alquilados: " . $this->numProductosAlquilados . "<br />" .
        "Total alquileres: " .  $this->numTotalAlquileres . "<br />";
    }
}
