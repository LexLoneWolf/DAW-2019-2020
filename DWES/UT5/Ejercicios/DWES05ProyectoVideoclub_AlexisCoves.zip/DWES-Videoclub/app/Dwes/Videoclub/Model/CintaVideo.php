<?php 

namespace Dwes\Videoclub\Model;

/**
 * Clase del soporte alquilable "cintas de vídeo"
 * 
 * Serán alquilables por los clientes.
 * 
 * @package Dwes\Videoclub\Model
 * @author LexLoneWolf <lareone91@gmail.com>
 */
class CintaVideo extends Soporte implements Resumible {

    //Atributos
    /**
     * Duración de la cinta en minutos
     * @var int
     */
    private $duracion;

    //Constructor
    public function __construct(string $titulo, int $numero, float $precio, int $duracion) {
        parent::__construct($titulo, $numero, $precio);
        $this->duracion = $duracion;
    }

    //Métodos
    /**
     * Muestra un resumen de CintaVideo
     * @return void
     */
    public function muestraResumen(): void {
        echo ("Pelicula en VHS:" .
        parent::muestraResumen() .
        "Duración: " . $this->duracion . " minutos");
    }
}
