<?php 

namespace Dwes\Videoclub\Model;

use Monolog\Logger;

/**
 * Clase abstracta Soporte
 * 
 * Define cada uno de los soportes alquilables del videoclub
 * 
 * @package Dwes\Videoclub\Model
 * @author LexLoneWolf <lareone91@gmail.com>
 */
abstract class Soporte implements Resumible {

    // Atributos
    /**
     * Constante con el IVA aplicable
     * @const IVA
     */
    public const IVA = 1.16;
    /**
     * Titulo del soporte
     * @var string
     */
    public $titulo;
    /**
     * Número identificador del soporte
     * @var int
     */
    protected $numero;
    /**
     * Precio del soporte
     * @var float
     */
    private $precio;
    /**
     * Indica si el soporte está alquilado
     * @var bool
     */
    protected $alquilado;

    // Constructor
    public function __construct(string $titulo, int $numero, float $precio) {
        $this->titulo = $titulo;
        $this->numero = $numero;
        $this->precio = $precio;
        $this->alquilado = false;
        $this->log = new Logger("VideoclubLogger");
    }

    // Getters y Setters
    public function getPrecio(): float {
        return $this->precio;
    }
    
    /**
     * calcula el precio con IVA del soporte
     * @return float
     */
    public function getPrecioConIva(): float {
        return $this->precio * self::IVA;
    }

    public function getNumero(): int {
        return $this->numero;
    }

    public function setAlquilado(bool $alquilado) {
        $this->alquilado = $alquilado;
    }

    public function getAlquilado() : bool {
        return $this->alquilado;
    }

    //Métodos
    /**
     * Muestra un resumen con las propiedades del soporte
     * @return void
     */
    public function muestraResumen(): void {
        echo "<br /> $this->titulo <br />" .
        $this->getPrecio() . " (IVA no incluido)";
    }
}
