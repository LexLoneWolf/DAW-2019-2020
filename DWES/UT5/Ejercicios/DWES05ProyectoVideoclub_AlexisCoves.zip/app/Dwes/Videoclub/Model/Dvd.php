<?php 

namespace Dwes\Videoclub\Model;

use Monolog\Logger;

/**
 * Clase del soporte alquilable "Dvd"
 * 
 * alquilables por los clientes
 * 
 * @package Dwes\Videoclub\Model
 * @author LexLoneWolf <lareone91@gmail.com>
 */
class Dvd extends Soporte implements Resumible {

    //Atributos
    /**
     * Idiomas en los que está el dvd
     * @var string
     */
    public $idiomas;
    /**
     * Formato de pantalla del dvd
     * @var string
     */
    private $formatPantalla;

    //Constructor
    public function __construct(string $titulo, int $numero, float $precio, string $idiomas, string $formatPantalla) {
        parent::__construct($titulo, $numero, $precio);
        $this->idiomas = $idiomas;
        $this->formatPantalla = $formatPantalla;
        $this->log = new Logger("VideoclubLogger");
    }

    //Getters & Setters
    public function getIdiomas() : string {
        return $this->idiomas;
    }

    public function getFormatoPantalla() : string {
        return $this->formatPantalla;
    }

    // Métodos
    /**
     * Muestra un resumen de las propiedades del dvd.
     * @return string
     */
    public function muestraResumen(): string {
        $resumen = "<br />Pelicula en DVD:" .
        parent::muestraResumen() .
        "<br />Idiomas: " . $this->idiomas . "<br />Formato: " . $this->formatPantalla;
        echo $resumen;

        return $resumen;
    }
}
