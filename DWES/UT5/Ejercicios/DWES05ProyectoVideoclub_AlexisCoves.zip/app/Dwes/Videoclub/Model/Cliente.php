<?php 

namespace Dwes\Videoclub\Model;

use \Dwes\Videoclub\Util\SoporteYaAlquiladoException;
use \Dwes\Videoclub\Util\CupoSuperadoException;
use \Dwes\Videoclub\Util\SoporteNoEncontradoException;
use \Dwes\Videoclub\Util\LogFactory;
use Monolog\Handler\RotatingFileHandler;

/**
 * Clase Cliente
 * 
 * El cliente puede alquilar y devolver productos, mostrar un resumen de su información
 * y listar los productos alquilados.
 * 
 * @package Dwes\Videoclub\Model
 * @author LexLoneWolf <lareone91@gmail.com>
 */
class Cliente implements Resumible {
    
    //Atributos
    public $nombre;
    /**
     * Identificador del cliente
     * @var int $numero
     */
    private $numero;
    /**
     * Colección de soportes alquilados
     * @var array <Soporte>
     */
    private $soportesAlquilados;
    /**
     * Número de soportes alquilados
     * @var int
     */
    private $numSoportesAlquilados;
    /**
     * Número máximo de soportes que el cliente puede tener alquilados
     * @var int
     */
    private $maxAlquilerConcurrente;

    private $log;

    //Constructor
    public function __construct(string $nombre, int $numero, int $maxAlquilerConcurrente = 3) {
        $this->nombre = $nombre;
        $this->numero = $numero;
        $this->soportesAlquilados = [];
        $this->numSoportesAlquilados = 0;
        $this->maxAlquilerConcurrente = $maxAlquilerConcurrente;
        $this->log = LogFactory::getLogger();
    }

    //Getters y Setters
    public function setNumero(int $numero): Cliente {
        $this->numero = $numero;
        return $this;
    }

    public function getNumero(): int {
        return $this->numero;
    }

    //Métodos

    /**
     * Comprueba si el cliente ya tiene alquilado el soporte
     * @param Soporte $s Soporte a comprobar
     * @return bool devuelve true si lo tiene alquilado
     */
    public function tieneAlquilado(Soporte $s): bool {
        $alquilado = false;
        if (in_array($s, $this->soportesAlquilados)) {
            $alquilado = true;    
        }
        return $alquilado;
    }

    /**
     * Añade un soporte al array de soportes alquilados y muestra un resumen
     * @param Soporte $s Soporte a alquilar
     * @throws SoporteYaAlquiladoException Lanza una excepción si el soporte ya está alquilado
     * @throws CupoSuperadoException Lanza una excepción si el cliente ha superado el máximo de alquileres permitidos
     * @return Cliente 
     */
    public function alquilar(Soporte $s): Cliente {

        if ($this->tieneAlquilado($s)) {
            $datos = [
            "Cliente: " => $this->numero,
            "Soporte: " => $s->titulo
            ];
            $this->log->warning("Soporte ya alquilado", $datos);
            throw new SoporteYaAlquiladoException($s->titulo);
        } else if ($this->numSoportesAlquilados >= $this->maxAlquilerConcurrente) {
            $datos = ["Cliente: " => $this->numero, "Soporte: " => $s->titulo, "Máximo de alquileres" => $this->maxAlquilerConcurrente];
            $this->log->warning("Cupo superado", $datos);
            throw new CupoSuperadoException($this->maxAlquilerConcurrente);
        } else {
            $this->numSoportesAlquilados++;
            $this->soportesAlquilados[$s->getNumero()] = $s;
            $s->setAlquilado(true);
            $this->log->info("Alquilado soporte a: " . $this->nombre);
            $s->muestraResumen();
        }
        return $this;
    }

    /**
     * Elimina del array de soportes alquilados el soporte con el número recibido por parámetro
     * @param int $numSoporte Número de soporte a devolver
     * @throws SoporteNoEncontradoException Lanza una excepción si no encuentra el soporte
     * @return Cliente
     */
    public function devolver(int $numSoporte): Cliente {
        $soportesAlquilados = $this->soportesAlquilados;
        if ($this->numSoportesAlquilados > 0) {
            if (array_key_exists($numSoporte, $soportesAlquilados)) {
                $datos = [
                "Cliente" => $this->numero,
                "Soporte" => $this->soportesAlquilados[$numSoporte],
                ];
                $this->numSoportesAlquilados--;
                $this->log->info("Soporte devuelto correctamente", $datos);
                unset($this->soportesAlquilados[$numSoporte]);
            } else {
                $datos = [
                "Cliente" => $this->numero,
                "Soporte" => $numSoporte
                ];
                $this->log->warning("Soporte no encontrado", $datos);
                throw new SoporteNoEncontradoException($numSoporte, 1);
            }
        } else {
            $datos = ["Cliente" => $this->numero];
            $this->log->warning("Este cliente no tiene alquilado ningún elemento",);
            throw new SoporteNoEncontradoException();
        }
        return $this;
    }

    /**
     * Muestra la cantidad de soportes alquilados por un cliente
     * @return string
     */
    public function muestraResumen(): string {
        $resumen = $this->nombre . "<br />
        Alquileres actuales: " . $this->numSoportesAlquilados;
        echo $resumen;

        return $resumen;
    }

    /**
     * Lista un resumen de los alquileres de un cliente
     * @return void
     */
    public function listarAlquileres(): void {
        echo "<br /><strong>El cliente tiene: " . $this->numSoportesAlquilados . " soportes alquilados</strong><br />";
        foreach ($this->soportesAlquilados as $soporte) {
            $soporte->muestraResumen();
        }
    }
}
    