<?php 

namespace Dwes\Videoclub\Model;

interface Resumible {
    
    public function muestraResumen() : string;
}
