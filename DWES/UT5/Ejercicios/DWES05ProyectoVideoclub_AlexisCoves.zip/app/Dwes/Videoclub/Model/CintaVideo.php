<?php 

namespace Dwes\Videoclub\Model;

/**
 * Clase del soporte alquilable "cintas de vídeo"
 * 
 * Serán alquilables por los clientes.
 * 
 * @package Dwes\Videoclub\Model
 * @author LexLoneWolf <lareone91@gmail.com>
 */
class CintaVideo extends Soporte implements Resumible {

    //Atributos
    /**
     * Duración de la cinta en minutos
     * @var int
     */
    private $duracion;

    //Constructor
    public function __construct(string $titulo, int $numero, float $precio, int $duracion) {
        parent::__construct($titulo, $numero, $precio);
        $this->duracion = $duracion;
    }

    //Getters & Setters
    public function getDuracion() : int {
        return $this->duracion;
    }

    //Métodos
    /**
     * Muestra un resumen de CintaVideo
     * @return string
     */
    public function muestraResumen(): string {
        $resumen = "Pelicula en VHS:" .
        parent::muestraResumen() .
        "Duración: " . $this->duracion . " minutos";
        echo $resumen;

        return $resumen;
    }
}
