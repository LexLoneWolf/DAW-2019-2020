<?php 

namespace Dwes\Videoclub\Util;

use Monolog\Logger;
use Psr\Log\LoggerInterface;
use Monolog\Handler\RotatingFileHandler;

class LogFactory {

    public static function getLogger(string $canal = "VideoclubLogger") : LoggerInterface {
        $log = new Logger($canal);
        $log->pushHandler(new RotatingFileHandler("logs/videoclub.log", 0, Logger::DEBUG));
        return $log;
    }
}