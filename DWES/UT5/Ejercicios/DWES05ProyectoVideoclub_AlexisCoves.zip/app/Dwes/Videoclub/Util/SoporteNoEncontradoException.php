<?php 

namespace Dwes\Videoclub\Util;

/**
 * Excepción de soporte no encontrado
 * 
 * se lanza cuando no se encuentra el soporte en los alquileres del cliente
 * o cuando no existe
 * 
 * @package Dwes\Videoclub\Util
 * @author LexLoneWolf <lareone91@gmail.com>
 */
class SoporteNoEncontradoException extends VideoclubException {
      
    /**
     * Lanza un mensaje indicando que no se ha encontrado el cliente
     * @return void
     */
    public function soporteNoEncontrado() : void {
        echo "No se ha podido encontrar el soporte " . $this->message .  
        " en los alquileres de este cliente<br />";
    }

    /**
     * Lanza un mensaje de error indicando que el cliente no tiene alquilado ningún elemento
     * @return void
     */
    public function soporteNoAlquilado() : void {
        echo "Este cliente no tiene alquilado ningún elemento";
    }

    /**
     * Llama a los métodos soporteNoEncontrado() y soporteNoAlquilado en función del código de error
     * @return void
     */
    public function noEncontrado() : void {
        if ($this->code == 1) {
            $this->soporteNoEncontrado();
        } else {
            $this->soporteNoAlquilado();
        }
    }
}
