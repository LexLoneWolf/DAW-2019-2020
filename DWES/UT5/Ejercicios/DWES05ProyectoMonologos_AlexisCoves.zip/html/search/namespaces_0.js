var searchData=
[
  ['dwes_10',['Dwes',['../namespace_dwes.html',1,'']]],
  ['monologos_11',['Monologos',['../namespace_dwes_1_1_monologos.html',1,'Dwes']]]
];
