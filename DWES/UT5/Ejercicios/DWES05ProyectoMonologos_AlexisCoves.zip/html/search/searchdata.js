var indexSectionsWithContent =
{
  0: "_dghs",
  1: "h",
  2: "d",
  3: "h",
  4: "_dgs"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Namespaces",
  3: "Files",
  4: "Functions"
};

