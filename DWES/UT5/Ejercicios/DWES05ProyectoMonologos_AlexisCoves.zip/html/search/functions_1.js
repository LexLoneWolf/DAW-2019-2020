var searchData=
[
  ['despedir_14',['despedir',['../class_dwes_1_1_monologos_1_1_hola_monolog.html#a1831b8ecab69639b2b84f89c1963fed9',1,'Dwes::Monologos::HolaMonolog']]]
];
