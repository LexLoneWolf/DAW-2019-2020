var searchData=
[
  ['saludar_8',['saludar',['../class_dwes_1_1_monologos_1_1_hola_monolog.html#aa1d1defa197bd7b78fd37c50b2db0dc9',1,'Dwes::Monologos::HolaMonolog']]]
];
