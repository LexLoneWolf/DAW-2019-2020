var searchData=
[
  ['gethora_4',['getHora',['../class_dwes_1_1_monologos_1_1_hola_monolog.html#a0d22cd2d80aedf38e7afa8b1529f611b',1,'Dwes::Monologos::HolaMonolog']]],
  ['getultimossaludos_5',['getUltimosSaludos',['../class_dwes_1_1_monologos_1_1_hola_monolog.html#ae0f1ca1f7109e65241a068382c542173',1,'Dwes::Monologos::HolaMonolog']]]
];
