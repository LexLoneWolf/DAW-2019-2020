var searchData=
[
  ['holamonolog_9',['HolaMonolog',['../class_dwes_1_1_monologos_1_1_hola_monolog.html',1,'Dwes::Monologos']]]
];
