var searchData=
[
  ['holamonolog_6',['HolaMonolog',['../class_dwes_1_1_monologos_1_1_hola_monolog.html',1,'Dwes::Monologos']]],
  ['holamonolog_2ephp_7',['HolaMonolog.php',['../_hola_monolog_8php.html',1,'']]]
];
