<?php 

    $a = $_GET["a"];
    $b = $_GET["b"];
    $c = $_GET["c"];
    $dis=($b*$b) - (4*$a*$c);
    $x = 0;
    $x2 = 0;

    if ($dis > 0) {
        $x = (-$b + sqrt($dis)) / (2*$a);
        $x2 = (-$b - sqrt($dis)) / (2*$a);
        echo "Las 2 posibles soluciones son: x= $x x= $x2"; 
    } else if ($dis == 0) {
        $x = -$b / (2*$a);
        echo "La solución es: x= $x";
    } else {
        $x = "No tiene solución";
    }

?>