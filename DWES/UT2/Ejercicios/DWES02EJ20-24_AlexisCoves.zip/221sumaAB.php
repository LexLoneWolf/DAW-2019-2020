<?php 

    $inicio = $_GET["inicio"];
    $fin = $_GET["fin"];
    $n = 0;

    if ($inicio % 2 != 0) {
        $inicio++;
    }

    for ($i=$inicio; $i < $fin ; $i++) { 
        $n += $i;
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>221sumaAB</title>
</head>
<body>
    <p><?= $n ?></p>
</body>
</html>