<?php 
    $n = $_GET["n"];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>223tablaMultiplicar</title>
</head>
<body>

    <table>
        <?php
        for ($i=1; $i <= 10; $i++) {   
        ?>
            <tr>   
                <td><?= $n ?></td>
                <td><?= "x" ?></td>
                <td><?= $i ?></td>
                <td><?= "="; ?></td>
                <td><?= $n*$i ?></td>
            </tr>
        <?php } ?>
    </table>

</body>
</html>