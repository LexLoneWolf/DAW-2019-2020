<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>220pares50</title>
</head>
<body>

    <ul>
        <?php 
        for ($i=0; $i <= 50 ; $i+=2) { 
        ?>
            <li><?= $i ?></li>
        <?php } ?>
    </ul>

</body>
</html>