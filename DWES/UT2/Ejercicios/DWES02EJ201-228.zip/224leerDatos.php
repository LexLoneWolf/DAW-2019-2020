<?php 
   $cantidad = $_GET["cantidad"];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>224leerDatos</title>
</head>
<body>

    <form action="224sumarDatos.php">
        <?php 
        for ($i=1; $i <= $cantidad; $i++) { 
        ?>
            <p>
                <label for="caja <?= $i ?>">Caja <?= $i ?></label>
                <input type="number" name="caja<?= $i ?>" id="caja<?= $i ?>" />
                
            </p>
        <?php } ?>
        <input type="hidden" name="cantidad" value="<?= $cantidad ?>" />
        <input type="submit" value="enviar">
    </form>
</body>
</html>