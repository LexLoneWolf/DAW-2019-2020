<?php 

    $edad = $_GET["edad"];
    $pulsacionesDesc = $_GET["pulsacionesDesc"];
    $intensidad = 50;
    

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>225karvonen</title>
</head>
<body>
    <table>

        <tr>
            <td>Edad:<?= $edad ?></td>
            <td>Pulsaciones Descanso:<?= $pulsacionesDesc?></td>
        </tr>
        <tr>
            <td>Intensidad</td>
            <td>Pulsaciones</td>
        </tr>

        <?php
        for ($i=$intensidad; $i <= 100; $i+=5) { 
            $pulsaciones = (((220 - $edad) - 
            $pulsacionesDesc) * 
            ($i/100)) + 
            $pulsacionesDesc;
        ?>
            <tr>
                <td><?= $i ?>%</td>
                <td><?= $pulsaciones ?> ppm</td>
            </tr>
        <?php } ?>

    </table>
</body>
</html>