<?php 

    $base = $_GET["base"];
    $exponente= $_GET["exponente"];
    $res = 1;


    for ($i=0; $i < $exponente ; $i++) { 
        $res *= $base;
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>222potencia</title>
</head>
<body>
    <p><?= $res ?></p>
</body>
</html>