<?php 

    $filas = $_GET["filas"];
    $columnas = $_GET["columnas"];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css">
    <title>227cuadrado</title>
</head>
<body>
    <table>
    
        <?php 
        for ($i=1; $i <= $filas; $i++) { 
        ?>
            <tr>
                <?php
                for ($j=1; $j <= $columnas; $j++) { 
                    if ($i == 1 || $j == 1 || $i == $filas || $j == $columnas) {
                ?>
                        <td><?= "$i:$j" ?></td>
                    <?php  } 
                    else {
                ?>
                        <td></td>
                    <?php }
                } ?>
            </tr>
        <?php } ?>
    
    </table>
</body>
</html>