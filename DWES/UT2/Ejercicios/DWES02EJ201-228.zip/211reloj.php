<?php 

    $hora = $_GET["hora"];
    $min = $_GET["min"];
    $seg = $_GET["seg"];
    $res = "";

    $seg++;

    if ($seg > 59) {
        $seg = 0;
        $min++;
        
        if ($min > 59) {
            $min = 0;
            $hora++;

            if ($hora > 23) {
                $hora = 0;
            }
        }
    }
    
    $res = "$hora:$min:$seg";
    echo $res;
?>