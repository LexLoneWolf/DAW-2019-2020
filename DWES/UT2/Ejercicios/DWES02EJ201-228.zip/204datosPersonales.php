<?php 
        $nombre = $_GET["nombre"];
        $apellido1 = $_GET["apellido1"];
        $apellido2 = $_GET["apellido2"];
        $email = $_GET["email"];
        $anoNaciminto = $_GET["anoNacimiento"];
        $telefono = $_GET["telefono"];   
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>204datosPersonales</title>
    <link rel="stylesheet" href="./css/style.css">
</head>
<body>
    
    <table>
        <tr>
            <th>Nombre</th>
            <td><?php echo "$nombre" ?></td>
        </tr>
        <tr>
            <th>Apellidos</th>
            <td><?php echo "$apellido1 $apellido2" ?></td>
        </tr>
        <tr>
            <th>Email</th>
            <td><?php echo "$email" ?></td>
        </tr>
        <tr>
            <th>Año de nacimiento</th>
            <td><?php echo "$anoNaciminto" ?></td>
        </tr>
            <th>Teléfono</th>
            <td><?php echo "$telefono" ?></td>
        </tr>
    </table>

</body>
</html>


