<?php 

    $dia = $_GET["dia"];
    $mes = $_GET["mes"];
    $anyo = $_GET["anyo"];

    $dia++;

    if ($mes == 2) {
        if($dia > 28) {
            $mes++;
            $dia = 1;
        }
    } else if ($mes == 4 || $mes == 6 || $mes == 9 || $mes == 11) {
        if ($dia > 30) {
            $mes++;
            $dia = 1;
        }
    } else {
        if ($dia > 31) {
            $mes++;
            $dia = 1;

            if ($mes > 12) {
                $mes = 1;
                $anyo++;
            }
        }
    }
    
    $res = "$dia/$mes/$anyo";
    echo $res;
    
?>