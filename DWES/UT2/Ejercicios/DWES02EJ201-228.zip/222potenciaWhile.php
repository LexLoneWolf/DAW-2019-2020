<?php 

    $base = $_GET["base"];
    $exponente= $_GET["exponente"];
    $res = 1;
    $i = 0;
    
    while ($i < $exponente) {
        $res *= $base;
        $i++;
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>222potenciaWhile</title>
</head>
<body>
    <p><?= $res ?></p>
</body>
</html>