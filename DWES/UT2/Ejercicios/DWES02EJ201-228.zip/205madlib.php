<?php 
   $sust = $_GET["sust"];
   $verbo = $_GET["verbo"];
   $adj = $_GET["adj"];
   $adv = $_GET["adv"];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>205madlib.php</title>
</head>
<body>
    <p>
        <?php 
            echo "Te gusta $verbo con tu $sust $adj $adv";
        ?>
    </p>    
</body>
</html>