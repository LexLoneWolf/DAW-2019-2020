<?php 

    $base = $_GET["base"];
    $exponente= $_GET["exponente"];
    $res = 1;
    $i = 0;

    if ($exponente == 0) {
        $res = 1;
    } else {
        do {
            $res *= $base;
            $i++;
        } while ($i < $exponente);
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>222potenciaDoWhile</title>
</head>
<body>
    <p><?= $res ?></p>
</body>
</html>