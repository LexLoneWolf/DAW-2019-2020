<?php 
    $n = 0;
    for ($i=1; $i <= 10 ; $i++) { 
        $n += $i;
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>221suma110</title>
</head>
<body>

    <p><?= $n ?></p>   

</body>
</html>