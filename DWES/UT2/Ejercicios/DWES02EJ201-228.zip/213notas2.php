<?php 

    $nota = $_GET["nota"];

    if ($nota == "suspenso") {
        echo "1-4: $nota";
    } else if ($nota == "aprobado") {
        echo "5: $nota";
    } else if ($nota == "bien") {
        echo "6: $nota";
    } else if ($nota == "notable") {
        echo "7-8: $nota";
    } else if ($nota == "sobresaliente") {
        echo "9-10: $nota";
    } else {
        echo "Nota no válida.";
    }

?>