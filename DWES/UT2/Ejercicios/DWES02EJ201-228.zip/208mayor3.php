<?php

    $a = $_GET["a"];
    $b = $_GET["b"];
    $c = $_GET["c"];

    if($a>$b) {
        if($a>$c) {
            echo "El mayor número es $a";
        }
    } else if ($b>$c) {
        echo "El mayor número es $b";
    } else {
        echo "El mayor número es $c";
    }   
?>