<?php 

    $nota = $_GET["nota"];

    if ($nota < 5) {
        echo "$nota: Suspenso";
    } else if ($nota < 6){
        echo "$nota: Aprobado";
    } else if ($nota < 7) {
        echo "$nota: Bien";
    } else if ($nota < 9) {
        echo "$nota: Notable";
    } else {
        echo "$nota: Sobresaliente";
    }

?>