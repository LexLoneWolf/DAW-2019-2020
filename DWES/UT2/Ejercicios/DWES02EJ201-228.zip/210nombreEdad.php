<?php 

    $edad = $_GET["edad"];

    if($edad<3 && $edad>0){
        echo "Es un bebé";
    } else if($edad>=3 && $edad<=12) {
        echo "Es un niño";
    } else if($edad>=13 && $edad<=17) {
        echo "Es un adolescente";
    } else if($edad>=18 && $edad<=66) {
        echo "Es un adulto";
    } else if($edad>=67 && $edad <100) {
        echo "Está jubilado";
    } else if($edad>=100) {
        echo "Está probablemente muerto";
    } else {
        echo "Es una idea";
    }
        
?>