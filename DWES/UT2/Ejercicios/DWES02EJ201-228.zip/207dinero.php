<?php 

    $cantidad = $_GET["cantidad"];
    $cantidadInicial = $cantidad;
    $b500 = $cantidad/500;
    $cantidad %= 500;
    $b200 = $cantidad/200;
    $cantidad %= 200;
    $b100 = $cantidad/100;
    $cantidad %= 100;
    $b50 = $cantidad/50;
    $cantidad %= 50;
    $b20 = $cantidad/20;
    $cantidad %= 20;
    $b10 = $cantidad/10;
    $cantidad %= 10;
    $b5 = $cantidad/5;
    $cantidad %= 5;
    $m2 = $cantidad/2;
    $cantidad %= 2;
    $m1 = $cantidad/1;
    
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>207dinero</title>
</head>
<body>

    <p><?php echo "Cantidad: " . intval($cantidadInicial); ?></p>
    <p><?php echo intval($b500) . " billetes de 500"; ?></p>
    <p><?php echo intval($b200) . "billetes de 200"; ?></p>
    <p><?php echo intval($b100) . "billetes de 100"; ?></p>
    <p><?php echo intval($b50) . " billetes de 50"; ?></p>
    <p><?php echo intval($b20) . " billetes de 20"; ?></p>
    <p><?php echo intval($b10) . " billetes de 10"; ?></p>
    <p><?php echo intval($b5) . " billetes de 5"; ?></p>
    <p><?php echo intval($m2) . " monedas de 2"; ?></p>
    <p><?php echo intval($m1) . " monedas de 1"; ?></p>

</body>
</html>