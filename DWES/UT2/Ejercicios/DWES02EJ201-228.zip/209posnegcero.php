<?php 

    $n = $_GET["n"];

    if($n>0) {
        echo "El número $n es positivo";
    } else if($n<0) {
        echo "El número $n es negativo";
    } else {
        echo "El número es $n";
    }

?>