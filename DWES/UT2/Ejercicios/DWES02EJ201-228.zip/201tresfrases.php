<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>201tresfrases</title>
</head>
<body>

    <?php /*Imprimir cadenas de texto de 3 formas distintas
    
    Primera forma*/
    ?>
    <p><?php echo "Cadena de texto con echo " ?></p>

    <?php // Segunda forma ?>

    <p><?php print("Cadena de texto con print") ?></p>

    <?php // Tercera forma ?>

    <p><?= "Cadena de texto con etiqueta abreviada" ?></p>
    
</body>
</html>