<?php 

    $inicio = $_GET["inicio"];
    $fin = $_GET["fin"];

    if ($inicio % 2 != 0) {
        $inicio++;
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>220paresAB</title>
</head>
<body>

    <ul>
        <?php
        for ($i = $inicio; $i <= $fin ; $i+=2) { 
        ?>
            <li><?= $i ?></li>
        <?php } ?>
    </ul>

</body>
</html>