<?php 
    $nombre = "Alexis";
    $apellido1 = "Coves";
    $apellido2 = "Berna";
    $email = "lareone91@gmail.com";
    $anoNaciminto = 1991;
    $telefono = 691317652;   
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/style.css">
    <title>203datosPersonales</title>
</head>
<body>
    
    <table>
        <tr>
            <th>Nombre</th>
            <td><?php echo "$nombre" ?></td>
        </tr>
        <tr>
            <th>Apellidos</th>
            <td><?php echo "$apellido1 $apellido2" ?></td>
        </tr>

        <tr>
            <th>Email</th>
            <td><?php echo "$email" ?></td>
        </tr>
        <tr>
            <th>Año de nacimiento</th>
            <td><?php echo "$anoNaciminto" ?></td>
        </tr>
            <th>Teléfono</th>
            <td><?php echo "$telefono" ?></td>
        </tr>
    </table>
    
</body>
</html>


