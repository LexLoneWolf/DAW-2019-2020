<?php 

   $sust = $_GET["sust"];
   $sust2= $_GET["sust2"];
   $sust3= $_GET["sust3"];
   $verbo = $_GET["verbo"];
   $verbo2 = $_GET["verbo2"];
   $adj = $_GET["adj"];
   $adj2 = $_GET["adj2"];
   $adv = $_GET["adv"];
   
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>205madlib2.php</title>
</head>
<body>

    <p>
        <?php 
            echo "¿Te gusta $verbo con tu $sust $adj $adv por el $sust2 mientras
            $verbo2 un/a $sust3 $adj2?";
        ?>
    </p>
       
</body>
</html>