<?php 
    $x = 166;
    $y = 999;
    $suma = $x+$y;
    $resta = $x-$y;
    $division = $x/$y;
    $multiplicacion = $x*$y;
?>  

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>202calculos</title>
</head>
<body>

    <p><?php echo "Valor de x = $x, Valor de y = $y"; ?></p>

    <p><?php echo "Suma de x + y = $suma"; ?></p>

    <p><?php echo "Resta de x - y = $resta"; ?></p>

    <p><?php echo "División de x / y = $division"; ?></p>
    
    <p><?php echo "Multiplicación de x * y = $multiplicacion"; ?></p> 

</body>
</html>