<?php 
    namespace app\Dwes\Videoclub\Model;
    
    interface Resumible {
        public function muestraResumen() : void;
    }
