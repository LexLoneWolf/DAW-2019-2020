<?php 
    namespace Dwes\Videoclub\Util;
    use Exception;
    class VideoclubException extends Exception {
        
    }

    
