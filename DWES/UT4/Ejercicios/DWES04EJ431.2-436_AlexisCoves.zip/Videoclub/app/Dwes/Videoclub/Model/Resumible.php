<?php 
    namespace Dwes\Videoclub\Model;
    
    interface Resumible {
        public function muestraResumen() : void;
    }
