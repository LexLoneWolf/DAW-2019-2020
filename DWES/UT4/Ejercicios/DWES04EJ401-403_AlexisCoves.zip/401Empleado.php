<?php 

    class Empleado {


        // Atributos
        private $nombre;
        private $apellidos;
        private $sueldo;

        // Getters y Setters

        public function setNombre(string $nombre) {
            $this->nombre=$nombre;
        }

        public function getNombre(): string {
            return $this->nombre;
        }

        public function setApellidos(string $apellidos) {
            $this->apellidos=$apellidos;
        }

        public function getApellidos(): string {
            return $this->apellidos;
        }

        public function setSueldo(int $sueldo) {
            $this->sueldo=$sueldo;
        }

        public function getSueldo(): int {
            return $this->sueldo;
        }

        // Métodos

        public function imprimirNombreCompleto(): string {
            $nombreCompleto = $this->nombre . " " . $this->apellidos;
            return $nombreCompleto;
        }

        public function debePagarImpuestos(): bool {
            $impuestos = false;

            if ($this->sueldo > 3333) {
                $impuestos = true;
            }

            return $impuestos;
        }
    }

    $e1 = new Empleado();
    $e1->setNombre("Alexis");
    $e1->setApellidos("Coves Berna");
    $e1->setSueldo(3334);
    
    $nombre = "<p>Nombre: " . $e1->imprimirNombreCompleto() . "</p>";
    $sueldo = "<p>Sueldo: " . $e1->getSueldo() . "</p>"; 
    $impuestos = "";

    if (!$e1->debePagarImpuestos()) {
        $impuestos = "<p>No debe pagar impuestos</p>";
    } else {
        $impuestos = "<p>Debe pagar impuestos</p>";
    }

    $empleado = $nombre . $sueldo . $impuestos;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>401Empleado</title>
</head>
<body>
    <?= $empleado ?>
</body>
</html>